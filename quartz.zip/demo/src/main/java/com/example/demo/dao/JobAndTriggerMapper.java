package com.example.demo.dao;

import java.util.List;

import com.example.demo.entity.JobAndTrigger;

public interface JobAndTriggerMapper {
	public List<JobAndTrigger> getJobAndTriggerDetails();
}
